Changes in UI Prototype file:
  - Redraw the home screen
  - Redraw the screen Part 1 of Mini Test
  - Redraw the screen Part 5 of Mini Test